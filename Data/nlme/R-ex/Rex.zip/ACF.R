### Name: ACF
### Title: Autocorrelation Function
### Aliases: ACF
### Keywords: models

### ** Examples

## see the method function documentation




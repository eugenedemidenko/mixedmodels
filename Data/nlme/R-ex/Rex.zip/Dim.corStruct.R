### Name: Dim.corStruct
### Title: Dimensions of a corStruct Object
### Aliases: Dim.corStruct
### Keywords: models

### ** Examples

Dim(corAR1(), getGroups(Orthodont))




### Name: lmList.groupedData
### Title: lmList Fit from a groupedData Object
### Aliases: lmList.groupedData
### Keywords: models

### ** Examples

fm1 <- lmList(Orthodont)
summary(fm1)




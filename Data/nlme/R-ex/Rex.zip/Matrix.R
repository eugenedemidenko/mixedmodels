### Name: Matrix
### Title: Assign Matrix Values
### Aliases: matrix<-
### Keywords: models

### ** Examples

## see the method function documentation




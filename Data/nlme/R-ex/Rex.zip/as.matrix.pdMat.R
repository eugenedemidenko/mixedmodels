### Name: as.matrix.pdMat
### Title: Matrix of a pdMat Object
### Aliases: as.matrix.pdMat
### Keywords: models

### ** Examples

as.matrix(pdSymm(diag(4)))




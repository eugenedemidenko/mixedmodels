### Name: varFunc
### Title: Variance Function Structure
### Aliases: varFunc
### Keywords: models

### ** Examples

vf1 <- varFunc(~age)




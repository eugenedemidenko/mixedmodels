### Name: Orthodont
### Title: Growth curve data on an orthdontic measurement
### Aliases: Orthodont
### Keywords: datasets

### ** Examples

formula(Orthodont)
plot(Orthodont)




### Name: corFactor
### Title: Factor of a Correlation Matrix
### Aliases: corFactor
### Keywords: models

### ** Examples

## see the method function documentation




### Name: plot.nffGroupedData
### Title: Plot an nffGroupedData Object
### Aliases: plot.nffGroupedData
### Keywords: models

### ** Examples

plot(Machines)
plot(Machines, inner = TRUE)




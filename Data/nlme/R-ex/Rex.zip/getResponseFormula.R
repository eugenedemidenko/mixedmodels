### Name: getResponseFormula
### Title: Extract Formula Specifying Response Variable
### Aliases: getResponseFormula
### Keywords: models

### ** Examples

getResponseFormula(y ~ x | g)




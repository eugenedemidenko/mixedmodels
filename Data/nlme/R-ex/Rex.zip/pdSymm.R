### Name: pdSymm
### Title: General Positive-Definite Matrix
### Aliases: pdSymm
### Keywords: models

### ** Examples

pd1 <- pdSymm(diag(1:3), nam = c("A","B","C"))
pd1




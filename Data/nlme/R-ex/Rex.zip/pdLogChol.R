### Name: pdLogChol
### Title: General Positive-Definite Matrix
### Aliases: pdLogChol
### Keywords: models

### ** Examples

pd1 <- pdLogChol(diag(1:3), nam = c("A","B","C"))
pd1




### Name: Variogram
### Title: Calculate Semi-variogram
### Aliases: Variogram
### Keywords: models

### ** Examples

## see the method function documentation




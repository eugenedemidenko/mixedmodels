### Name: Coef
### Title: Assign Values to Coefficients
### Aliases: coef<- coefficients<-
### Keywords: models

### ** Examples

## see the method function documentation




### Name: Soybean
### Title: Growth of soybean plants
### Aliases: Soybean
### Keywords: datasets

### ** Examples

summary(fm1 <- nlsList(SSlogis, data = Soybean))




### Name: gnlsStruct
### Title: Generalized Nonlinear Least Squares Structure
### Aliases: gnlsStruct Initialize.gnlsStruct
### Keywords: models

### ** Examples

gnls1 <- gnlsStruct(corAR1(), varPower())




### Name: Covariate
### Title: Assign Covariate Values
### Aliases: covariate<-
### Keywords: models

### ** Examples

## see the method function documentation



